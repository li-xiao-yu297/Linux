#!/bin/bash
BACKUP_PATH=/opt/backup/
MYSQL_DUMP=/usr/bin/mysqld
BACKUP_TIME=$(date +%Y%m%d.%H%M)
BACKUP_DB=python
DB_USER=python
DB_PAWD=123456

${MYSQL_DUMP} -u${DB_USER} -p${DB_PAWD} ${BACKUP_DB} > ${BACKUP_PATH}/${BACKUP_DB}.sql
if [ $? -ne 0  ];then
     echo "${BACKUP_TIME} mysqld error " >>  ${BACKUP_PATH}/dump.log
     exit 1
fi

tar -zcvf ${BACKUP_PATH}/${BACKUP_DB}.${BACKUP_TIME}.tar.gz ${BACKUP_PATH}/${BACKUP_DB}.sql 
rm -f ${BACKUP_PATH}/${BACKUP_DB}.sql 

#删除10天前的文件
find ${BACKUP_PATH} -name "*.tar.gz" -mtime +10 -exec rm -rfv {} \;
exit 0
