'''
    交互的输入学生成绩保存到excel表格
    当文件存在就追加
    不存在，则创建
'''
import xlwt
import pandas as pd
def test():

    try:
    
        name_list = []
        cj_list = []
        d = {'学生姓名':name_list,'成绩':cj_list}


        sname = input('请输入名字：')
        scj = input('请输入成绩:')
        name_list.append(sname)
        cj_list.append(scj)
        #把用户输入的追加到字典中去
        print(d)
        #f1表示存储原内容的对象
        f1 = pd.DataFrame(pd.read_excel('stu.xlsx'))
        f2 = pd.DataFrame(d)

        f = pd.concat([f1,f2]).to_excel('stu.xlsx',index=False)
        #把字典中的信息写入到表格中去

        #pd.DataFrame(d).to_excel('stu.xlsx', index=False)
        #print(pd.read_excel('stu.xlsx'))

    except:
        print('文件不存在')
        f1 = pd.DataFrame(d)
        f1.to_excel('stu.xlsx',index=False)
test()

