#!/bin/bash

#清空
iptables -F

#关闭firewalld
systemctl stop firewalld
systemctl disable firewalld

#下面这条是不允许访问
#iptables -P INPUT DROP
#添加规则
#开启22ssh端口
iptables -A INPUT tcp --dport 22 -j ACCEPT
#开启80端口
iptables -A INPUT tcp --dport 80 -j ACCEPT
#开启9000端口
iptables -A INPUT tcp --dport 9000 -j ACCEPT
#允许本服务器访问自己
iptables -A INPUT -s 127.0.0.1 -j ACCEPT
#允许192.168.0.103访问
iptables -A INPUT -s 192.168.0.103 -j ACCEPT
#不允许192.168.0.289连接到本服务器
iptables -A INPUT -s 192.168.0.289 -j DROP
#把开启3306端口追加到第一条规则
iptables -I INPUT 1 tcp --dport 3306 -j ACCEPT

