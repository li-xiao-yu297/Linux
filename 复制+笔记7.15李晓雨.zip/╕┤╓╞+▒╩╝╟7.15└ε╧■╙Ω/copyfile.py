#!/usr/bin/env python3

import os 
from shutil import copy2

def mycopy(src,dst):
    names = os.listdir(src)

    for name in names:
        srcname = os.path.join(src,name)
        dstname = os.path.join(dst,name)

        if os.path.isdir(srcname):
            if not os.path.exists(dstname):
                os.makedirs(dstname)
                print('ok')
            mycopy(srcname,dstname)
            print('复制目录成功')

        if os.path.isfile(srcname):
            copy2(srcname,dstname)
            print('文件复制成功')

mycopy('test','testb')
