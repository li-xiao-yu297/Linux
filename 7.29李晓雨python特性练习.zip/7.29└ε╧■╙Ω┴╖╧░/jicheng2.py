
class Person:

    def __init__(self,name,age):
        self.name = name
        self.age = age

    def say(self):
        print('hi')


class Student(Person):

    def __init__(self,name,age,score):
        self.name = name
        self.age = age
        self.score = score
    def say(self):
        print('hello')
s = Student('tom',18,99)
s.say()
print(s.name,s.age,s.score)
