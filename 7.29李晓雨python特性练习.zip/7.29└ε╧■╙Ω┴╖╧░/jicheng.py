
class Person:

    def say(self):
        print('hi')


class Student(Person):
    pass

s = Student()
s.say()
