#!/usr/bin/env python3
#封装
class Student:
    
    #私有化
    def __init__(self,name,age):
        self.__name = name
        self.__age = age

    
    #暴露接口
    def getName(self):
        return self.__name

    def getAge(self):
        return self.__age



s = Student('tom',18)
print(s._Student__age)
print(s.getName(),s.getAge())
