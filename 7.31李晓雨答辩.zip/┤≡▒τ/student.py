#!/usr/bin/env python3

import os
'''
    字段：学生姓名 班级 Linux PHP Python
    stu1 = {'id':1,'sname':'tom','bj':'1','Linux':100,}
'''

#
save_file = 'student1.txt'

def menu():
    print('''
      |-----------学生成绩系统--------|
      |                               |
      |===========主功能菜单==========|
      |                               |
      |                               |                               
      |      1.录入学生成绩           |
      |      2.查询学生成绩           |
      |      3.删除学生的成绩         |
      |      4.修改学生的成绩         |
      |      5.展示所有学生成绩       |
      |      0.退出系统               |
      |                               |
      |-------------------------------|

    ''')

#录入学生成绩
def add_info():
    #连续录入时存储信息的列表
    stu_info = []
    id = 0

    mark = True
    while mark:

        '''
            保存信息的文件
            1.文件存在
            2.文件不存在
        '''
        sname = input('输入学生的姓名:')
        if not sname:
            print('学生姓名不能为空')
            continue
        bj = input('输入学生的班级:')
        Linux = input('输入Linux成绩:')
        PHP = input('输入PHP成绩:')
        Python = input('输入Python成绩:')

        '''
            1.当文件存在并且文件内容不为空，也就是文件中有记录：
                id = max(id) + 1
            2.当文件存在但是文件内容为空
                id += 1
            3.当文件不存在
                id += 1

            4.连续输入的时候，stu_info不为空
                连续输入的时候产生的列表中的最大id
                id = max(new_id)

        '''
        #如果文件不存在，id自增1
        if not os.path.exists(save_file):
            id += 1

        #当文件存在且文件中有了记录，如何判断一个文件是否为空
        if os.path.exists(save_file) and os.path.getsize(save_file) ==0:
            id = 0
            id += 1
        if os.path.exists(save_file) and os.path.getsize(save_file) !=0:
            #打开文件并读取文件所有行
            with open(save_file) as f:
                #把整个文件内容存到一个列表当中
                alist = f.readlines()
            #print(alist)
            #使用eval函数把列表中字符串格式的字典转化为正常的字典
            stu_info2 = [eval(i) for i in alist]
            #获取到所有的id
            id_list = [stu_info2[i].get('id') for i in range(len(stu_info2))]
            #获取到最大的id
            id = max(id_list)
            
        #当文件存在文件中没有记录
            id += 1

        #当我们连续录入的时候，连续的数据被保村到一个列表中，就需要让这个列表中的id能自动增长，获取到这个列表中最大的那个id

        if stu_info:
            #在连续录入的情况下，获取到所有的id
            new_id = [stu_info[i].get('id') for i in range(len(stu_info))]
            max_id = max(new_id)
            id = max_id + 1


        new_stu = {'id':id,'sname':sname,'bj':bj,'Linux':Linux,'PHP':PHP,'Python':Python}
        stu_info.append(new_stu)

        key = input('是否继续录入y/n')
        if key == 'y':
            mark = True
        else:
            mark = False

    save(stu_info)


def save(stu_info):

    for info in stu_info:
        with open(save_file,'a+') as f:
            f.write(str(info) + '\n')
        
def show():
    format_title = '{:^6}{:^12}\t{:^12}{:^12}{:^12}{:^12}'
    format_data = '{:^6}{:^13}\t{:^15}{:^13}{:^15}{:^14}'
    print(format_title.format('ID','姓名','班级','Linux成绩','PHP成绩'    ,'Python成绩'))
    #读取文件内容，文件存在且文件有内容
    if os.path.exists(save_file) and os.path.getsize(save_file) !=0:
        with open(save_file) as f:
            stu_info = f.readlines()
            
            #在ide当中有一种功能叫打断点，发现文件读取过来的内容是一个列表，列表中的字典是字符串格式的
            #print(stu_info)
            #一定要边写边调试，及时调试
            '''
            调试的作用：
                1.当有错误的时候
                2.当你没有思路的时候
                3.当你有思路的时候，去验证你的思路
            '''
            for i in stu_info:
                #i是一个字典
                #print(i)
                #print(type(i))
                #把字符格式的字典转化为标准字典
                i = eval(i)
                id = i.get('id')
                sname = i.get('sname')
                bj = i.get('bj')
                Linux = i.get('Linux')
                PHP = i.get('PHP') 
                Python = i.get('Python')

                print(format_data.format(id,sname,bj,Linux,PHP,Python))
    else:
        print('什么也没找见')

def search():
    #根据学生姓名查询学生成绩
    format_title = '{:^6}{:^12}\t{:^12}{:^12}{:^12}{:^12}'
    format_data = '{:^6}{:^13}\t{:^15}{:^13}{:^15}{:^14}'
    sname  = input('输入要查询学生的姓名:')
    print(format_title.format('ID','姓名','班级','Linux成绩','PHP成绩','Python成绩'))
    if os.path.exists(save_file) and os.path.getsize(save_file) !=0:
        with open(save_file) as f:
            stu_info = f.readlines()
        #转为常规列表
        stu_info = [eval(i) for i in stu_info]
        name_list = [stu_info[i].get('sname') for i in range(len(stu_info))]
        if sname in name_list:
            for i in stu_info:
                if sname == i.get('sname'):
                    id = i.get('id')
                    sname = i.get('sname')
                    bj = i.get('bj')
                    Linux = i.get('Linux')
                    PHP = i.get('PHP')
                    Python = i.get('Python')
                    print(format_data.format(id,sname,bj,Linux,PHP,Python))
        else:
            print('学生名字不存在')


def modify():
     #根据输入的姓名，我们修改学生的成绩
     sname = input('请输入要修改的学生的姓名：')
     #读取文件
     with open(save_file) as f:
         stu_info = f.readlines()
 
     stu_info = [eval(i) for i in stu_info]
     name_list = [stu_info[i].get('sname') for i in range(len(stu_info)    )]
     #如果你要输入的姓名在这个文件中，才做对应的修改操作
 
     if sname in name_list:
         #就是把被修改的内容删除了，写入新的内容
         with open(save_file,'w') as f:
             opt = input('输入1,2,3分别修改Linux,PHP,Python的成绩：')
             for i in stu_info:
                 if sname == i.get('sname'):
                     if opt == '1':
                         Linux = input('修改Linux成绩：')
                         #我们是要修改列表中的字典，把用户输入的对应的成绩赋值给字典
                         i['Linux'] = Linux
                         print('ok')
                     if opt == '2':
                         PHP = input('修改PHP成绩：')
                         i['PHP'] = PHP
                         print('ok')
                     if opt == '3':
                         Python = input('修改Python成绩：')
                         i['Python'] = Python
                         print('ok')                                   
         save(stu_info)
     
     else:
         print('学生不存在')
#删除
def delete():
    #我们根据学生姓名来删除

    sname = input('输入你要删除的学生的姓名：')

    #要删除的学生的信息在文件中，

    with open(save_file) as f:
        stu_info = f.readlines()

    #把读取到的列表转化好
    #然后获取到学生姓名的列表
    stu_info = [eval(i) for i in stu_info]
    name_list = [stu_info[i].get('sname') for i in range(len(stu_info))]
    #print(name_list)

    #以覆盖写入的方式操作文件，把修改好的列表保存到文件中
    #方法1：
    with open(save_file,'w') as f:
        for i in stu_info:
            if i['sname'] == sname:
                stu_info.remove(i) #删除该字段
                print('删除成功')

    #方法2：
    #with open(save_file,'w') as f:
    #    for i in stu_info:
    #        #实现方法：把不是用户输入的用户名保存到文件
    #        if i['sname'] != sname:
    #            f.write(str(i) + '\n')
    #            print('ok')

    #学生的信息保存完整后，我们考虑id的自减的实现
    #id的操作方法：使用for循环变量整个列表的长度，id就是索引+1
    # 修改剩下学生的id id - 1
    for i in range(len(stu_info)):
        id = i + 1
        stu_info[i]['id'] = id

    save(stu_info)


    #show()



def main():
    while True: 
        menu()
        key = input('请选择功能：')
        if key == '1':
            add_info()
        if key == '2':
            search()
        if key == '3':
            delete()
        if key == '4':
            modify()
        if key == '5':
            show()

        if key == '0':
            break

if __name__ =='__main__':
    main()

